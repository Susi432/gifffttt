
let countdown = 10;
let countdownInterval = setInterval(() => {
    document.querySelector(".countdown").textContent = "Countdown: " + countdown;
    countdown--;
    if (countdown < 0) {
        clearInterval(countdownInterval);
        showMountainScene();
    }
}, 1000);

function showMountainScene() {
    document.querySelector(".mountain-scene").style.display = "block";
    setTimeout(() => {
        document.querySelector(".stars").style.display = "block";
    }, 2000);
}

const messages = {
    1: "You are a beautiful soul I have seen in my life.",
    2: "I never imagined a friendship like this—it’s special to me.",
    3: "Bro, never give up on anything you try.",
    4: "Always remember to keep smiling.",
    5: "One day, I’ll come meet you for real on a special day.",
    6: "Keep doing what you love.",
    7: "Control your anger sometimes, but protect your self-respect.",
    8: "Don’t mind the ones who judge—just keep moving.",
    9: "It’s going to be another special year—enjoy it fully!",
    10: "One last thing: remember the phrase—TREASURESTAR. That’s your key!"
};

let stars = document.querySelectorAll(".star");
stars.forEach((star, index) => {
    star.addEventListener("click", () => {
        alert(messages[index + 1]);
    });
});

function checkKey() {
    let keyInput = document.getElementById("keyInput").value;
    if (keyInput.toLowerCase() === "treasure star") {
        document.getElementById("treasure-box").style.display = "block";
        document.getElementById("treasure-message").classList.remove("hidden");
    } else {
        alert("Incorrect key! Try again.");
    }
}

function showFinalMessage() {
    document.getElementById("final-message").classList.remove("hidden");
}
